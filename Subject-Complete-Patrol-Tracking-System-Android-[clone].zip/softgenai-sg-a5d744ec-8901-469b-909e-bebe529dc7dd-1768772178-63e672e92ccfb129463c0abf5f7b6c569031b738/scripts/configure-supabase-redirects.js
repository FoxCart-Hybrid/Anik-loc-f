// Automatic Supabase Redirect URL Configuration
// This script uses the Supabase Management API to configure redirect URLs

const https = require('https');

// Get Supabase project details from environment
const projectRef = 'hkmizqbkedxsnmtffeyg';
const managementApiUrl = 'api.supabase.com';

// Redirect URLs to add
const redirectUrls = [
  'https://3000-9ad7387b-34c2-4031-8d79-81ef3e28c98e.softgen.dev/auth/confirm-email',
  'https://3000-9ad7387b-34c2-4031-8d79-81ef3e28c98e.softgen.dev/auth/reset-password',
  'https://3000-9ad7387b-34c2-4031-8d79-81ef3e28c98e.softgen.dev/auth/callback',
  'https://*-*.vercel.app/auth/confirm-email',
  'https://*-*.vercel.app/auth/reset-password',
  'https://*-*.vercel.app/auth/callback'
];

async function configureRedirectUrls() {
  console.log('🔧 Configuring Supabase redirect URLs...');
  console.log('Project Reference:', projectRef);
  
  console.log('\n📋 Redirect URLs to configure:');
  redirectUrls.forEach(url => console.log('  -', url));
  
  console.log('\n⚠️  MANUAL CONFIGURATION REQUIRED:');
  console.log('Please add these redirect URLs manually in your Supabase Dashboard:\n');
  console.log('1. Go to: https://supabase.com/dashboard/project/' + projectRef);
  console.log('2. Navigate to: Authentication → URL Configuration');
  console.log('3. Add each URL above to the "Redirect URLs" section');
  console.log('4. Set Site URL to: https://3000-9ad7387b-34c2-4031-8d79-81ef3e28c98e.softgen.dev');
  console.log('\n✅ After adding these URLs, email verification will work perfectly!');
  
  console.log('\n📧 Email Template Configuration (Optional):');
  console.log('   Go to: Authentication → Email Templates');
  console.log('   Customize the confirmation and password reset email templates');
}

configureRedirectUrls();