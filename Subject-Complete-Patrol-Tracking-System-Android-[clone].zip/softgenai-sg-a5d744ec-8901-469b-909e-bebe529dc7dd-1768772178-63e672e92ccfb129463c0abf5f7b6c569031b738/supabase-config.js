// Supabase Redirect URL Configuration Script
// This script configures the redirect URLs for email verification and password reset

const SUPABASE_PROJECT_REF = "hkmizqbkedxsnmtffeyg";
const SITE_URL = "https://3000-9ad7387b-34c2-4031-8d79-81ef3e28c98e.softgen.dev";

// Redirect URLs to configure
const REDIRECT_URLS = [
  // Development URLs
  `${SITE_URL}/auth/confirm-email`,
  `${SITE_URL}/auth/reset-password`,
  `${SITE_URL}/auth/callback`,
  
  // Wildcard for Vercel deployments
  "https://*-*.vercel.app/auth/confirm-email",
  "https://*-*.vercel.app/auth/reset-password",
  "https://*-*.vercel.app/auth/callback",
];

console.log("✅ Supabase Redirect URLs Configuration:");
console.log("Project:", SUPABASE_PROJECT_REF);
console.log("Site URL:", SITE_URL);
console.log("\nConfigured URLs:");
REDIRECT_URLS.forEach((url, i) => console.log(`  ${i + 1}. ${url}`));
console.log("\n📋 Please add these URLs to your Supabase Dashboard:");
console.log("   Go to: Authentication → URL Configuration → Redirect URLs");